# Talento-tech

<a href="https://www.inova.pr.gov.br/Pagina/Talento-Tech-PR" target="_blank"><img src="https://www.inova.pr.gov.br/sites/default/arquivos_restritos/files/styles/escala_940_largura_/public/imagem/2024-04/talento_tech_pr_-_logo.webp?itok=0RW0V1Ie" 
alt="Texto ALT da imagem aqui" border="10" /></a>
