# Aplicativo Calculadora

Programa utilizando Flutter.
- [**App-calculadora**](https://aula-talento-teck.github.io/app-calculadora/)

## Introdução

Este projeto é um ponto de partida para um aplicativo Flutter.
Alguns recursos para você começar se este for seu primeiro projeto Flutter:

- [Laboratório: Escreva seu primeiro aplicativo Flutter](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Amostras úteis do Flutter](https://docs.flutter.dev/cookbook)

Para obter ajuda para começar com o desenvolvimento do Flutter, veja a [documentação online](https://docs.flutter.dev/), que oferece tutoriais, amostras, orientação sobre desenvolvimento e uma referência completa da API.