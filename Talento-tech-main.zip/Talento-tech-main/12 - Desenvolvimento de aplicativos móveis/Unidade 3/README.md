# Unidade 3: Manipulação de Dados para persistência e Bibliotecas Básicas

Nesta unidade serão apresentados novos componentes para execução do projeto final especificamente a criação de estruturas necessárias para a visualização dos planetas já cadastrados, bem como manipulação dos mesmo, no que diz respeito a sua edição e exclusão.

Para orientar a realização das atividades previstas o aluno deverá assistir os vídeos da Unidade 3 ([**Mostrar planetas**](https://youtu.be/TfE63d2bA_E) **e** [**Alterar e excluir planeta**](https://youtu.be/ZNwxv5IDXdQ)), o aluno deverá realizar a atividade proposta e depois disponibilizar os links de acesso para as atividades realizadas.

**VÍDEO AULA:**

- [**Mostrar planetas**](https://youtu.be/TfE63d2bA_E)
- [**Alterar e excluir planeta**](https://youtu.be/ZNwxv5IDXdQ)

